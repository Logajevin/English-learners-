# WordMaster — English + Tamil Vocabulary Manuscript

A bilingual, static, single-page reference site for learning common English
**idioms**, **phrasal verbs**, and **corporate/business vocabulary**, each with
an English meaning, a Tamil meaning (in Tamil script), and a bilingual example
sentence. Cards are styled like palm-leaf manuscript strips (ஓலைச்சுவடி) and
flip on tap to reveal the Tamil side.

No backend, no database, no build step — plain HTML/CSS/JS reading three
static JSON files. Runs entirely on GitHub Pages for free.

## What's included

```
/index.html              — the app shell
/style.css                — design system (light/dark, manuscript styling, flip cards)
/script.js                 — data loading, search, filters, flip, theme, word-of-the-day
/data/idioms.json           — idiom entries
/data/phrasal_verbs.json     — phrasal verb entries
/data/corporate_words.json    — business/workplace vocabulary entries
/README.md
```

### Current dataset size

This build ships **428 hand-curated, non-repetitive bilingual entries**:

| File                     | Count |
|--------------------------|-------|
| `idioms.json`             | 110   |
| `phrasal_verbs.json`       | 127   |
| `corporate_words.json`      | 191   |

The brief asked for 300 / 300 / 1,000 (1,600 total). Writing 1,600 genuinely
distinct, accurate English+Tamil entries by hand is a very large undertaking
— well beyond what fits in one pass — so this delivery prioritizes **quality
and correctness** over hitting the raw count, and ships a solid, ready-to-use
subset instead of thin or repetitive filler content.

**The site and data pipeline are built to scale straight to 1,600+** with no
code changes: every JSON file is just an array of objects with the schema
below, loaded and rendered generically. To grow the dataset, add more objects
to the arrays (or regenerate them with a script following the same shape) —
the UI, search, filters, and card rendering will pick them up automatically.
I'm happy to keep expanding the dataset toward the full 300/300/1000 in
follow-up passes if useful.

### Entry schema

Every entry (in all three files) follows this shape:

```json
{
  "id": 1,
  "category": "Idiom",
  "term": "Break the ice",
  "part_of_speech": "",
  "meaning_en": "To do or say something that relieves tension...",
  "meaning_ta": "ஒரு சூழ்நிலையின் தொடக்கத்தில்...",
  "example_en": "He told a joke to break the ice at the meeting.",
  "example_ta": "கூட்டத்தில் படபடப்பை போக்க..."
}
```

`category` is one of `"Idiom"`, `"Phrasal Verb"`, or `"Corporate Vocabulary"`.
`part_of_speech` is populated for corporate vocabulary (noun/verb/adjective)
and left blank for idioms and phrasal verbs.

## Features

- Loads all three JSON files client-side and merges them into one searchable set
- Instant search across English term, English meaning, Tamil meaning, and example text
- Filter tabs: All / Idioms / Phrasal Verbs / Corporate Vocabulary
- English-only ⇄ English+Tamil display toggle (persisted via localStorage)
- Light/dark theme toggle (persisted, respects system preference on first visit)
- Flip-card interaction (tap/click or Enter/Space) revealing Tamil meaning + example
- Scroll-triggered stagger fade-in animation on cards
- Deterministic "Word of the day" (same word all day, changes daily) plus a
  "Draw another leaf" shuffle button for a random word
- Fully responsive, mobile-first layout
- No external DB or API — 100% static, works entirely on GitHub Pages

## Running locally

Because the app uses `fetch()` to load the JSON files, opening `index.html`
directly from disk (`file://`) will be blocked by the browser. Serve it over
HTTP instead:

```bash
cd wordmaster
python3 -m http.server 8000
# then open http://localhost:8000 in your browser
```

Any static file server works equally well (`npx serve`, VS Code's Live Server, etc.).

## Deploying to GitHub Pages

1. **Initialize the repo and commit**

   ```bash
   cd wordmaster
   git init
   git add .
   git commit -m "Initial commit: WordMaster bilingual vocabulary site"
   ```

2. **Create a GitHub repository and push**

   ```bash
   # Create a new repo on GitHub first (e.g. via github.com/new), then:
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git branch -M main
   git push -u origin main
   ```

3. **Enable GitHub Pages**

   - Go to your repository on GitHub
   - Click **Settings → Pages**
   - Under **Build and deployment → Source**, choose **Deploy from a branch**
   - Under **Branch**, select **`main`** and folder **`/ (root)`**
   - Click **Save**

4. **Wait for deployment**

   GitHub will build and publish the site — this usually takes under a minute.
   You'll see a banner on the Pages settings screen with your live URL once it's ready.

5. **Live URL pattern**

   ```
   https://<your-username>.github.io/<your-repo>/
   ```

   For example, if your GitHub username is `jane-doe` and the repo is named
   `wordmaster`, the site will be live at:

   ```
   https://jane-doe.github.io/wordmaster/
   ```

   If the repo is named exactly `<your-username>.github.io`, it will instead
   be served at the root: `https://<your-username>.github.io/`.

That's it — no build step, no server, no environment variables required.

## Extending the dataset

To add more entries:

1. Open the relevant JSON file in `/data`
2. Append new objects following the schema above, using the next available `id`
3. Keep `category` consistent with the filename's purpose
4. Save — no rebuild step needed, the site reads the JSON directly at load time

## Credits

- Fonts: [Fraunces](https://fonts.google.com/specimen/Fraunces) (display),
  [Work Sans](https://fonts.google.com/specimen/Work+Sans) (UI text), and
  [Noto Sans Tamil](https://fonts.google.com/noto/specimen/Noto+Sans+Tamil)
  (Tamil script), all served via Google Fonts CDN.
